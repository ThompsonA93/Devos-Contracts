exports.readCounter = require("./read-automation-counter.js")
