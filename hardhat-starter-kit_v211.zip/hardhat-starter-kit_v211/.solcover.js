module.exports = {
    skipFiles: ['test/fuzzing/AutomationCounterEchidnaTest.sol', 'test/MockLinkToken.sol', 'test/MockOracle.sol', 'test/MockV3Aggregator.sol', 'test/VRFCoordinatorV2Mock.sol'],
};