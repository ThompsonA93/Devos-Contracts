const { network } = require("hardhat")
const { loadFixture, time } = require("@nomicfoundation/hardhat-network-helpers")
const { networkConfig, developmentChains } = require("../../helper-hardhat-config")
const { assert, expect } = require("chai")

// Generate randomized String
const generateString = (length) =>
    Math.random().toString(32).substring(2, length);

// Randomly chooses from predefined set of nationalities
const generateNationality = () => {
    var nationalities = ["Austria", "Egypt", "Germany", "Japan", "Turkey", "China", "Russia"];
    return nationalities[Math.floor(Math.random() * nationalities.length)];
}

// Generates 1 oder 2 
const generateVote = () => {
    return Math.floor(Math.random() * 2) + 1;
}


!developmentChains.includes(network.name)
    ? describe.skip
    : describe("Devos_Archive Unit Tests", async function () {
        // We define a fixture to reuse the same setup in every test.
        // We use loadFixture to run this setup once, snapshot that state,
        // and reset Hardhat Network to that snapshot in every test.
        async function deployArchiveFixture() {
            const [deployer] = await ethers.getSigners()
            const devosArchiveFactory = await ethers.getContractFactory("Devos_Archive")
            const devosArchive = await devosArchiveFactory
                .connect(deployer)
                .deploy()

            return { deployer, devosArchive }
        }

        describe("#success", async function () {
            it("Deployment of Devos-Archive", async function () {
                const { deployer, devosArchive } = await loadFixture(deployArchiveFixture);

                const linkTokenFactory = await ethers.getContractFactory("MockLinkToken")
                const linkToken = await linkTokenFactory.connect(deployer).deploy()
                
                const mockOracleFactory = await ethers.getContractFactory("MockOracle")
                const mockOracle = await mockOracleFactory.connect(voterOne).deploy(linkToken.address)
                    
                const jobId = ethers.utils.toUtf8Bytes(networkConfig[chainId]["jobId"])
                const fee = networkConfig[chainId]["fee"]
                


                const devosBallotFactory = await ethers.getContractFactory("Devos_Ballot");
                const devosBallot = devosBallotFactory.connect(deployer).deploy(
                    devosArchiveContract.address,
                    generateString(10),
                    generateString(10),
                    1,
                    generateNationality(),
                    mockOracle.address,
                    jobId,
                    fee,
                    linkToken.address
                )

            })
        })

        describe("#failure", async function () {
            it("should be able to call performUpkeep after time passes", async function () {
                const { deployer, devosArchive } = await loadFixture(deployArchiveFixture);

            })
        })
    })
